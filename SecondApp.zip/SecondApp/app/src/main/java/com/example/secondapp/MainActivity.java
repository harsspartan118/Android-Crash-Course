package com.example.secondapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //  Add a toolbar : Step 4
        //  We tell Android to use the toolbar that we added as the new toolbar
        Toolbar toolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);
        //  For step 6, goto res -> menu -> toolbar_menu.xml

        //  Code to open second activity starts here
        Button bNext = findViewById(R.id.button_next);
        bNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  Create a message object that can be used to start the second activity.
                //  We specify the sender (MainActivity) and the receiver (SecondActivity) of the message.
                Intent intentNext = new Intent(MainActivity.this, SecondActivity.class);

                //  Send the message
                startActivity(intentNext);
            }
        });
        //  End of code to open second activity
    }

    //  Add a Toolbar : Step 7
    //  We connect our toolbar with the icons in toolbar_menu.xml
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }
    //  For step 8, see below

    //  Add a Toolbar : Step 8 (last step)
    //  We show a message when the toolbar icon is pressed
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_save) {
            Toast.makeText(this, "Save icon pressed", Toast.LENGTH_SHORT).show();
        }
        return true;
    }
    //  End of code to add a toolbar
}

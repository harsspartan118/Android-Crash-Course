package com.example.calculatorapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Stack;

public class MainActivity extends AppCompatActivity {
    private static final Spanned HTML_DIV = Html.fromHtml("&#247;");
    private static final Spanned HTML_MUL = Html.fromHtml("&#215;");
    private static final Spanned HTML_ADD = Html.fromHtml("&#43;");
    private static final Spanned HTML_SUB = Html.fromHtml("&#8722;");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button bAdd = findViewById(R.id.bAdd);
        Button bSub = findViewById(R.id.bSub);
        Button bDiv = findViewById(R.id.bDiv);
        Button bMul = findViewById(R.id.bMul);
        Button bDot = findViewById(R.id.bDot);
        Button bEqu = findViewById(R.id.bEqu);
        Button bDel = findViewById(R.id.bDel);
        Button bZero = findViewById(R.id.b0);
        tv = findViewById(R.id.text);

        Button[] bNum = prepareNumberButtons();

        bAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.append(HTML_ADD);
            }
        });
        bSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.append(HTML_SUB);
            }
        });
        bMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.append(HTML_MUL);
            }
        });
        bDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.append(HTML_DIV);
            }
        });
        bDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence expr = tv.getText();
                if (expr.length() > 0 && "".equals(expr) == false) {
                    tv.setText(expr.subSequence(0, expr.length() - 1));
                }
            }
        });
        bDot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.append(".");
            }
        });
        bZero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.append("0");
            }
        });

        bDel.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                tv.setText("");
                return true;
            }
        });

        bEqu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String expr = tv.getText().toString();
                try {
                    float result = evaluateInfix(expr);
                    tv.setText(String.valueOf(result));
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, "Expression may be invalid", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private TextView tv;

    //  May throw one of several exceptions if the expression is illegal.
    private float evaluateInfix(String expression) throws Exception{
        final char div = HTML_DIV.charAt(0);
        final char mul = HTML_MUL.charAt(0);
        final char add = HTML_ADD.charAt(0);
        final char sub = HTML_SUB.charAt(0);

        Stack<Float> operandStack = new Stack<>();
        Stack<Character> operatorStack = new Stack<>();

        // Separate out the operands and format them.
        String[] operandStrings = expression.split("[" + div + mul + add + sub + "]");
        int numOperands = 0;
        for (String operand : operandStrings) {
            if (!operand.equals("")) {
                numOperands++;
            }
        }

        float[] operands = new float[numOperands];
        for (int i = 0, j = 0; i < operandStrings.length; ++i) {
            if (!operandStrings[i].equals("")) {
                operands[j] = Float.parseFloat(operandStrings[i]);
                j++;
            }
        }

        //  If first number is negative, format it accordingly.
        if (expression.charAt(0) == sub) {
            operands[0] *= -1;
            expression = expression.substring(1);
        }

        // Start evaluation
        int operandCounter = 0;
        for (int i = 0; i < expression.length(); ++i) {
            char ch = expression.charAt(i);
            if ((ch == add || ch == sub) && i != 0) {
                //  Format negative numbers if any.
                char prevChar = expression.charAt(i - 1);
                if (prevChar == add || prevChar == sub || prevChar == mul || prevChar == div) {
                    operands[operandCounter] *= ch == sub ? -1 : 1;
                    expression = expression.substring(0, i) + expression.substring(i + 1);
                } else {
                    //  Only evaluate if operator does not represent the sign of a number.
                    operandStack.push(operands[operandCounter]);
                    operandCounter++;

                    if (!operatorStack.empty() && (operatorStack.peek() == mul || operatorStack.peek() == div)) {
                        //  Execute higher precedence operators first
                        char operator = operatorStack.pop();
                        float op1 = operandStack.pop();
                        float op2 = operandStack.pop();
                        float result = operator == mul ? op1 * op2 : op2 / op1;
                        operandStack.push(result);
                    }

                    operatorStack.push(ch);
                }
            } else if (ch == div || ch == mul) {
                operandStack.push(operands[operandCounter]);
                operandCounter++;
                operatorStack.push(ch);
            }
        }
        //  Include last operand
        operandStack.push(operands[operandCounter]);

        //  Evaluate the remaining operators from stack
        while (!operatorStack.empty()) {
            char operator = operatorStack.pop();
            float op1 = operandStack.pop();
            float op2 = operandStack.pop();
            float result = 0;
            if (operator == add) {
                result = op1 + op2;
            } else if (operator == sub) {
                result = op2 - op1;
            } else if (operator == mul) {
                result = op1 * op2;
            } else if (operator == div) {
                result = op2 / op1;
            }
            operandStack.push(result);
        }

        return operandStack.pop();
    }

    private Button[] prepareNumberButtons() {
        Button[] bNum = new Button[9];
        bNum[0] = findViewById(R.id.b1);
        bNum[1] = findViewById(R.id.b2);
        bNum[2] = findViewById(R.id.b3);
        bNum[3] = findViewById(R.id.b4);
        bNum[4] = findViewById(R.id.b5);
        bNum[5] = findViewById(R.id.b6);
        bNum[6] = findViewById(R.id.b7);
        bNum[7] = findViewById(R.id.b8);
        bNum[8] = findViewById(R.id.b9);

        for (int i = 0; i < 9; ++i) {
            final int finalI = i;
            bNum[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    tv.append(String.valueOf(finalI +1));
                }
            });
        }

        return bNum;
    }
}

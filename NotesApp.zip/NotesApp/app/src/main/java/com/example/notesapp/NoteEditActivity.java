package com.example.notesapp;

import android.content.SharedPreferences;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.InputFilter;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class NoteEditActivity extends AppCompatActivity {
    static final String TAG_FILE_NAME = "FILE_NAME";
    static final String PREF_FILE_NAME = "MY_PREF";
    static final String KEY_FILE_COUNTER = "FILE_COUNTER";

    private boolean editMode = false;
    private EditText etTitle, etContent;
    private TextView tvTitle, tvContent;
    private String fileName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_edit);

        Toolbar toolbar = findViewById(R.id.toolbar_noteEdit);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false);

        etTitle = findViewById(R.id.editText_noteEdit_title);
        etContent = findViewById(R.id.editText_noteEdit_content);
        tvTitle = findViewById(R.id.text_noteEdit_titleLabel);
        tvContent = findViewById(R.id.text_noteEdit_contentLabel);

        fileName = getIntent().getStringExtra(TAG_FILE_NAME);
        if (fileName == null) {
            //  New note
            setEditMode(true);
        }
        else {
            //  Existing note
            setEditMode(false);
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(openFileInput(fileName)));
                String title = reader.readLine();
                String line;
                StringBuilder builder = new StringBuilder();
                while ((line = reader.readLine()) != null) {
                    builder.append(line);
                }
                reader.close();
                tvTitle.setText(title);
                tvContent.setText(builder.toString());
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (editMode) {
            setEditMode(false);
        }
        else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_noteEdit_edit :
                setEditMode(true);
                break;
            case R.id.action_noteEdit_discard :
                if (editMode) {
                    // Discard changes
                    editMode = false;
                    tvTitle.setVisibility(View.VISIBLE);
                    tvContent.setVisibility(View.VISIBLE);
                    etTitle.setVisibility(View.GONE);
                    etContent.setVisibility(View.GONE);
                    invalidateOptionsMenu();
                }
                else {
                    // Delete note
                    if (fileName != null) {
                        deleteFile(fileName);
                        Toast.makeText(this, "Note deleted", Toast.LENGTH_SHORT).show();
                    }
                    finish();
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu_note_edit, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        if (editMode) {
            menu.findItem(R.id.action_noteEdit_edit).setVisible(false);
        }
        else {
            menu.findItem(R.id.action_noteEdit_edit).setVisible(true);
        }
        return true;
    }

    @Override
    protected void onStop() {
        if (editMode) {
            saveNote(etTitle.getText().toString(), etContent.getText().toString());
        }
        super.onStop();
    }

    private void saveNote(String title, String content) {
        SharedPreferences preferences = getSharedPreferences(PREF_FILE_NAME, MODE_PRIVATE);
        int fileCounter = preferences.getInt(KEY_FILE_COUNTER, 0);
        if (fileName == null) {
            fileCounter++;
            fileName = "note_" + fileCounter;
        }

        try {
            FileOutputStream outputStream = openFileOutput(fileName, MODE_PRIVATE);
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream));
            writer.write(title);
            writer.newLine();
            writer.write(content);
            writer.flush();
            writer.close();

            preferences.edit().putInt(KEY_FILE_COUNTER, fileCounter).apply();
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setEditMode(boolean editMode) {
        this.editMode = editMode;
        if (editMode) {
            tvTitle.setVisibility(View.GONE);
            tvContent.setVisibility(View.GONE);
            etTitle.setVisibility(View.VISIBLE);
            etContent.setVisibility(View.VISIBLE);

            etTitle.setText(tvTitle.getText());
            etContent.setText(tvContent.getText());
            invalidateOptionsMenu();
        }
        else {
            tvTitle.setVisibility(View.VISIBLE);
            tvContent.setVisibility(View.VISIBLE);
            etTitle.setVisibility(View.GONE);
            etContent.setVisibility(View.GONE);

            Editable content = etContent.getText();
            Editable title = etTitle.getText();
            tvContent.setText(content);

            if ("".equals(title.toString())) {
                tvTitle.setText(content.length() < 25
                        ? content
                        : content.subSequence(0, 25));
            }
            else {
                tvTitle.setText(title);
            }
            if (!"".equals(title.toString()) || !"".equals(content.toString())) {
                saveNote(tvTitle.getText().toString(), tvContent.getText().toString());
            }
            invalidateOptionsMenu();
        }
    }
}

package com.example.notesapp;

import android.content.Intent;
import android.content.res.Configuration;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private ActionBarDrawerToggle drawerToggle;
    private ListView lvNotes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar_main);
        toolbar.setNavigationIcon(R.drawable.ic_menu);
        setSupportActionBar(toolbar);

        lvNotes = findViewById(R.id.list_main);
    }

    @Override
    protected void onStart() {
        super.onStart();
        final Map<String, String> titlesAndFiles = getTitlesAndFiles();
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1,
                new ArrayList<String>(titlesAndFiles.keySet()));
        lvNotes.setAdapter(adapter);

        lvNotes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String title = adapter.getItem(position);
                String fileName = titlesAndFiles.get(title);
                Intent noteEditIntent = new Intent(MainActivity.this, NoteEditActivity.class);
                noteEditIntent.putExtra(NoteEditActivity.TAG_FILE_NAME, fileName);
                startActivity(noteEditIntent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_main_add :
                startActivity(new Intent(MainActivity.this, NoteEditActivity.class));
                break;
        }
        return true;
    }

    private Map<String, String> getTitlesAndFiles() {
        String[] allFiles = fileList();
        HashMap<String, String> filesAndTitles = new HashMap<>(allFiles.length);
        for (String file : allFiles) {
            if (file.startsWith("note")) {
                try {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(openFileInput(file)));
                    String title = reader.readLine();
                    filesAndTitles.put(title, file);
                    reader.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return filesAndTitles;
    }
}
